package com.example;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/API")
public class WeatherController {

	@Value("${app.title}")
	String title;

	Map<String, String> data = new HashMap<>();

	@PostConstruct
	public void init() {
		data.put("Delhi", "Very Very Hot");
		data.put("Pune", "Always Cool");
		data.put("Hyderabad", "Very Cool");
		data.put("Mumbai", "Very Hot");
	}

	@GetMapping(path = "/INFO", produces = MediaType.TEXT_PLAIN_VALUE)
	public String info() {
		System.out.println("=================== WeatherController.info() ====================");
		StringBuilder responseBuilder = new StringBuilder();
		responseBuilder.append("Current Time : ");
		responseBuilder.append(LocalDateTime.now());
		responseBuilder.append("\n");
		responseBuilder.append(title);
		responseBuilder.append("\n");
		responseBuilder.append("Weather is cool outside.");
		return responseBuilder.toString();

	}

	@GetMapping(path = "/INFO/CITY/{cityName}", produces = MediaType.TEXT_PLAIN_VALUE)
	public String infoAboutCity(@PathVariable String cityName) {
		System.out.println("=================== WeatherController.infoAboutCity() ====================");

		StringBuilder responseBuilder = new StringBuilder();
		responseBuilder.append("Current Time : ");
		responseBuilder.append(LocalDateTime.now());
		responseBuilder.append("\n");
		responseBuilder.append(title);
		responseBuilder.append("\n");
		responseBuilder.append("Weather is ");
		responseBuilder.append(data.get(cityName));
		responseBuilder.append(" in ");
		responseBuilder.append(cityName);
		responseBuilder.append("!!!!");
		return responseBuilder.toString();

	}

}
