insert into car_detail values(100,'Cruze','Chevlolet',200000.00);
insert into car_detail values(101,'X1','BMW',450000.00);
insert into car_detail values(102,'X6','BMW',750000.00);
insert into car_detail values(103,'X3','BMW',450000.00);
insert into car_detail values(104,'X2','BMW',250000.00);
insert into car_detail values(105,'X5','BMW',850000.00);

