package com.example.rest.resource;

import java.util.List;
import java.util.logging.Logger;

//Spring MVC imports
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//HATEOAS imports
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;


//User imports
import com.example.model.Car;
import com.example.service.CarService;

import io.swagger.annotations.ApiOperation;

//@Controller
@RestController
@RequestMapping(path = "/car")
public class CarResource {

	Logger logger = Logger.getLogger(CarResource.class.getName());

	@Autowired
	CarService carService;

	// REST API URI -- GET http://localhost:5050/luxurycars/car/getInfo
	@RequestMapping(path = "/getInfo", method = RequestMethod.GET, produces = { "text/plain" })
	// @ResponseBody
	public String info() {
		logger.info("================ Inside info() ===================");
		return "Wonderful Luxury Cars";
	}

	// Read a Car
	// REST API URI -- GET http://localhost:5050/luxurycars/car/getInfo
	// @RequestMapping(path = "/car/getInfoAbout", method = RequestMethod.GET,
	// produces = { "application/json" })
	// @RequestMapping(path = "/car/getInfoAbout", method = RequestMethod.GET,
	// produces = { MediaType.APPLICATION_JSON_VALUE })
	// @RequestMapping(path = "/car/getInfoAbout", method = RequestMethod.GET,
	// produces = { MediaType.APPLICATION_JSON_VALUE,
	// MediaType.APPLICATION_XML_VALUE })
	@GetMapping(path = "/getInfoAbout", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public Car carInfo() {
		logger.info("================ Inside carInfo() ===================");
		return new Car(1000, "Q5", "Audi", 4500000.00);
	}

	// Read a Car by Fix VIN
	@GetMapping(path = "/getCar", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value="Find a Car resource by fixed VIN-105",notes="Plus will give linnks to oter related resources like getAllCars")
	public Resource<Car> getCarByVIN() {
		logger.info("================ Inside getCarByVIN() ===================");
		Resource<Car> resource = new Resource<Car>(carService.readCarByVIN(105));
		
		ControllerLinkBuilder linkToResource1 = linkTo(methodOn(this.getClass()).getCarByLiveVIN(100));
		ControllerLinkBuilder linkToResource2 = linkTo(methodOn(this.getClass()).getCarByLiveVIN(102));
		ControllerLinkBuilder linkToResource3 = linkTo(methodOn(this.getClass()).getAllCars());
		
		resource.add(linkToResource1.withRel("single-car"));
		resource.add(linkToResource2.withRel("single-car"));
		resource.add(linkToResource3.withRel("all-cars"));
		
		return resource;
	}

	// Read a Car by VIN supplied by API consumer
	@GetMapping(path = "/getCar/{vin}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Car getCarByLiveVIN(@PathVariable("vin") int vin) {
		logger.info("================ Inside getCarByLiveVIN() ===================");
		return carService.readCarByVIN(vin);
	}

	// Read a Car by Make

	// Read all Car
	@GetMapping(path = "/getCars", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Car> getAllCars() {
		logger.info("================ Inside getAllCars() ===================");
		return carService.readAllCars();
	}

	// Add new Car
	@PostMapping(path = "/addCar", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.TEXT_PLAIN_VALUE })
	public String addCar(@RequestBody Car car) {
		logger.info("================ Inside addCar() ===================");
		car.setVin((int) (Math.random() * 500));

		System.out.println("DATA DUMP ======= " + car);

		if (carService.addCar(car) > 0)
			return "Car with vin '" + car.getVin() + "' added successfully.";
		else
			return "Car could not be added.";
	}

	// Update existing Car by VIN
	@PutMapping(path = "/updateCar/{vin}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Car updateCar(@RequestBody Car car, @PathVariable("vin") int vin) {
		logger.info("================ Inside updateCar() ===================");
		car.setVin(vin);
		System.out.println("DATA DUMP ======= " + car);
		return carService.modifyCar(car);
	}

	// Delete existing Car by VIN
	@DeleteMapping(path = "/deleteCar/{vin}", produces = { MediaType.TEXT_PLAIN_VALUE })
	public String deleteCar(@PathVariable("vin") int vin) {
		logger.info("================ Inside deleteCar() ===================");
		carService.removeCar(vin);
		return "Car with vin '" + vin + "' deleted successfully.";

	}

}
