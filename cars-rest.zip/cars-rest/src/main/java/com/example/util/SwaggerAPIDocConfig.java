package com.example.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerAPIDocConfig {

	Contact CONTACT = new Contact("Ritesh Tyagi", "https://github.com/misguided-coder", "hi2tyagi@yahoo.com");

	ApiInfo API_INFO = new ApiInfo("Luxury Cars", "It is all about luxury and costly Cars", "1.0", "urn:tos", CONTACT, "Apache 2.0",
			"http://www.apache.org/licenses/LICENSE-2.0");

	Set<String> PRODUCES_AND_CONSUMES = new HashSet<String>(
			Arrays.asList("application/json", "application/xml", "text/xml", "text/json"));

	@Bean
	public Docket apiDoc() {
		Docket docket = new Docket(DocumentationType.SWAGGER_2);
		docket.groupName("MINDLESS-CODERS");
		docket.host("120.20.4.10");
		docket.apiInfo(API_INFO);
		docket.produces(PRODUCES_AND_CONSUMES);
		docket.consumes(PRODUCES_AND_CONSUMES);
		return docket;
	}
}