package com.example;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class FuelRowMapper implements RowMapper<Fuel>{
	
	@Override
	public Fuel mapRow(ResultSet rs, int rowNum) throws SQLException {
		Fuel fuel = new Fuel();
		fuel.setId(rs.getInt(1));
		fuel.setCity(rs.getString(2));
		fuel.setTodayPrice(rs.getDouble(3));
		return fuel;
	}

}
