package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FuelDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public Fuel findPriceByCity(String city) {
		System.out.println("Inside FuelDAO.findPriceByCity()!!!!!");
		Object parms[] = { city };
		return jdbcTemplate.queryForObject("select * from fuel_price_master where city=?", parms, new FuelRowMapper());
	}
}
