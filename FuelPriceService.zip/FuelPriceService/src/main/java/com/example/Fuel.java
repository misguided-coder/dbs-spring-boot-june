package com.example;

public class Fuel {
	
	int id;
	String city;
	double todayPrice;
	
	public Fuel() {
	}

	public Fuel(String city, double todayPrice) {
		this.city = city;
		this.todayPrice = todayPrice;
	}
	
	public Fuel(int id, String city, double todayPrice) {
		this.id = id;
		this.city = city;
		this.todayPrice = todayPrice;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getTodayPrice() {
		return todayPrice;
	}
	public void setTodayPrice(double todayPrice) {
		this.todayPrice = todayPrice;
	}

	
	
	
}
