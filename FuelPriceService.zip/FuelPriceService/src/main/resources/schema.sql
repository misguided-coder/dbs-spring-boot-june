DROP TABLE IF EXISTS fuel_price_master;

CREATE TABLE fuel_price_master(
	id INT NOT NULL,
	city VARCHAR(30) NOT NULL,
	price DOUBLE(10,4),
	PRIMARY KEY (id));