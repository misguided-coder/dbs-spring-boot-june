insert into fuel_price_master values(1,'Delhi',78.60);
insert into fuel_price_master values(2,'Pune',80.70);
insert into fuel_price_master values(3,'Hyderabad',84.20);
insert into fuel_price_master values(4,'Chennai',70.00);