package com.example;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/API")
public class TransportController {

	@Value("${sports.title}")
	String title;
	
	@Value("${sports.info}")
	String description;
	
	@GetMapping(path = "/INFO",produces=MediaType.TEXT_PLAIN_VALUE)
	public String info() {
		System.out.println("=================== TransportController ====================");
		StringBuilder responseBuilder = new StringBuilder();
		responseBuilder.append("Current Time : ");
		responseBuilder.append(LocalDateTime.now());
		responseBuilder.append("\n");
		responseBuilder.append(title);
		responseBuilder.append("\n");
		responseBuilder.append(description);
		return responseBuilder.toString();
	}

}
