package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransportMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransportMSApplication.class, args);
	}

}
