package com.example.postprocessor;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CalculatorService {

	@Value("Simple Math Calculator")
	String title;
	
	public CalculatorService() {
		System.out.println("Inside CalculatorService constructor!!!!!");
	}
	
	@PostConstruct
	public void init() {
		System.out.println("Inside CalculatorService init()!!!!!");
		System.out.printf("Title : %s!!%n",title);
	}

	@PreDestroy
	public void clean() {
		System.out.println("Inside CalculatorService clean()!!!!!");
	}

	public void sum(int arg1, int arg2) {
		System.out.printf("SUM : %s%n", arg1 + arg2);
	}

}
