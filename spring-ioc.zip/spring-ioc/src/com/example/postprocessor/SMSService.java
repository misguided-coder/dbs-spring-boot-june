package com.example.postprocessor;

import org.springframework.stereotype.Service;

@Service("smsService")
public class SMSService {

	public SMSService() {
		System.out.println("Inside SMSService constructor!!!!!");
	}

	public void send() {
		System.out.printf("SMS is sent to  : %s%n", "Bill Gates");
	}
}
