package com.example.postprocessor;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"com/example/postprocessor/appCxt.xml");
		System.out.println("IoC Container is started");

		CalculatorService calculator = applicationContext.getBean("calculatorService",CalculatorService.class); 
		calculator.sum(10, 2);
	
		EmailService emailService = applicationContext.getBean("emailService",EmailService.class);
		emailService.send();
		
		SMSService sMSService = applicationContext.getBean("smsService",SMSService.class);
		sMSService.send();
		
		
		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
