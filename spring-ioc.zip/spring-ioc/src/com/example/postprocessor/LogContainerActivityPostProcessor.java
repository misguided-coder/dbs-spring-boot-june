package com.example.postprocessor;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

@Component
public class LogContainerActivityPostProcessor implements BeanFactoryPostProcessor {

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory container) throws BeansException {
		
		try {
			FileWriter fileWriter = new FileWriter("C:/dbs-spring-hyderabad-workspace/spring-ioc/logs/trace.log", true);
			fileWriter.write("IoC Container started at "+LocalDateTime.now());
			fileWriter.write("\nIoC Container loaded  "+container.getBeanDefinitionCount()+" beans.");
			fileWriter.write("\n");
			fileWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
