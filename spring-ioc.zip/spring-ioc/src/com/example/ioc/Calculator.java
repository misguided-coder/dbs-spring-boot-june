package com.example.ioc;

public class Calculator {

	public Calculator() {
		System.out.println("Inside Calculator constructor!!!!!");
	}

	public void sum(int arg1, int arg2) {
		System.out.printf("SUM : %s%n", arg1 + arg2);
	}

	public void diff(int arg1, int arg2) {
		System.out.printf("DIFF : %s%n", arg1 - arg2);
	}

}
