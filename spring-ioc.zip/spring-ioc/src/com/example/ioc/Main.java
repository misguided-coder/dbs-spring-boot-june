package com.example.ioc;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		// IoC Container is started
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/example/ioc/appCxt.xml");
		System.out.println("IoC Container is started");

		// Calculator calculator = new Calculator(); // NoN IoC Style
		// Calculator calculator = (Calculator)
		// applicationContext.getBean("calculator"); //IoC Style
		// calculator.sum(10, 2);
		// calculator.diff(10, 2);

		// User 1
		Calculator calculator1 = (Calculator) applicationContext.getBean("calculator"); // IoC Style
		System.out.println(calculator1);

		// User 2
		Calculator calculator2 = (Calculator) applicationContext.getBean("calculator"); // IoC Style
		System.out.println(calculator2);

		// IoC Container is stopped
		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
