package com.example.di;

import java.util.List;

public class AccountService {

	int accountNo;
	AccountDAO accountDAO;
	List<String> emails;

	public AccountService(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}

	/*
	 * public void setAccountDAO(AccountDAO accountDAO) { this.accountDAO =
	 * accountDAO; }
	 */

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public void setEmails(List<String> emails) {
		this.emails = emails;
	}

	public void deposit() {
		System.out.println("Inside AccountService deposit()!!!!");
		System.out.printf("Amount deposited to : %s%n", accountNo);
		System.out.printf("Notification sent to : %s%n", emails);
		accountDAO.update();
	}
}
