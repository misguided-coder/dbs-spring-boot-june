package com.example.di;

public class AccountDAO {

	public void update() {
		System.out.println("Inside AccountDAO update()!!!!");
	}
}
