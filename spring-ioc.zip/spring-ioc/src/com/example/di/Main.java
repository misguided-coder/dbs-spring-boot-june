package com.example.di;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/example/di/appCxt.xml");
		System.out.println("IoC Container is started");

		AccountService accountService = applicationContext.getBean("accountService",AccountService.class);
		accountService.deposit();
		
		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
