package com.example.zero;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class CourseService {
	
	@Autowired
	@Qualifier("uniqueSequence")
	long courseId;
	
	public CourseService() {
		System.out.println("Inside CourseService constructor!!!!");
	}
	
	@PostConstruct
	public void init() {
		System.out.println("Inside CourseService init()!!!!!");
	}

	@PreDestroy
	public void clean() {
		System.out.println("Inside CourseService clean()!!!!!");
	}
	
	public void addCourse(){
		System.out.printf("Course added to DB and Course ID : %s!!%n",courseId);
	}

	public List<String> listAllCourses(){
		List<String> courses = Arrays.asList("JPA","Hibernate","Spring","Core Java");
		return courses;
	}
}
