package com.example.zero;

import org.springframework.stereotype.Repository;

@Repository
public class EmailDAO {

	public EmailDAO() {
		System.out.println("Inside EmailDAO constructor!!!!!");
	}

	public void isValid() {
		System.out.printf("Mail address is valid!!!!%n");
	}
}
