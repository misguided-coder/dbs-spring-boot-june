package com.example.zero;

import java.time.LocalDateTime;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class TimeLoggerPostProcessor implements BeanPostProcessor {
 
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.printf("Inside TimeLoggerPostProcessor postProcessBeforeInitialization() for %s bean!!!!%n",beanName);
		return bean;
	}
	
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.printf("Bean %s instance created at %s!!!!%n",beanName,LocalDateTime.now());
		return bean;
	}
}
