package com.example.zero;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan("com.example.zero")
public class ApplicationConfiguration {

	// @Bean(initMethod="init",destroyMethod="clean")
	@Bean
	@Scope("singleton")
	@Lazy
	public CourseService courseService() {
		return new CourseService();
	}
	
	@Bean
	public long uniqueSequence() {
		return (long) (Math.floor(Math.random()*5000));
	}

	@Bean
	public String weatherStatus() {
		if(LocalDate.now().getDayOfMonth() < 15) 
			return "Sunny Weather";
		else if (LocalDate.now().getDayOfMonth() >= 15) 
			return "Cool Weather";
	
		return "Normal Weather";
	}
	
	/*@Bean
	public EmailService emailService() {
		return new EmailService();
	}
	
	@Bean
	public SMSService smsService() {
		return new SMSService();
	}*/

}
