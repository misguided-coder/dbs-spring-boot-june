package com.example.zero;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		System.out.println("IoC Container is started");

		CourseService courseService = applicationContext.getBean("courseService",CourseService.class);
		System.out.println(courseService.listAllCourses());
		courseService.addCourse();
		
		EmailService emailService = applicationContext.getBean("emailService",EmailService.class);
		emailService.send();
		
		SMSService smsService = applicationContext.getBean(SMSService.class);
		smsService.send();

		
		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
