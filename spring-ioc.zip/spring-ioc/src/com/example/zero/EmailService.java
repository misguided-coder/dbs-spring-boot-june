package com.example.zero;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

	EmailDAO emailDAO;

	@Autowired
	public void setEmailDAO(EmailDAO emailDAO) {
		this.emailDAO = emailDAO;
	}

	public EmailService() {
		System.out.println("Inside EmailService constructor!!!!!");
	}

	public void send() {
		emailDAO.isValid();
		System.out.printf("Mail is sent to  : %s%n", "Bill Gates");
	}
}
