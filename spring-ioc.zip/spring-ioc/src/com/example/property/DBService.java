package com.example.property;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("databaseService")
public class DBService {

	@Value("${dbs.jdbc.driver}")
	String driver;
	
	public void addtoDB() {
		System.out.printf("Data added to DB using %s driver!!!%n", driver);
	}
}
