package com.example.property;

import org.springframework.stereotype.Component;

@Component
public class SequenceGenerator {

	public long generate() {
		return (long) (Math.floor(Math.random()*1000));
	}
}
