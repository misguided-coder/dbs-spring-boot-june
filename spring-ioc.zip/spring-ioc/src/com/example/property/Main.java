package com.example.property;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(
				ApplicationConfiguration.class);
		System.out.println("IoC Container is started");

		EmailService emailService = applicationContext.getBean("emailService", EmailService.class);
		emailService.send();

		DBService databaseService = applicationContext.getBean("databaseService", DBService.class);
		databaseService.addtoDB();

		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
