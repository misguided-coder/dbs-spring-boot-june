package com.example.property;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

	@Value("#{sequenceGenerator.generate()}")
	long uniqueStamp;

	@Value("${dbs.title}")
	String title;
	
	@Value("${dbs.email.server}")
	String host;
	
	@Value("${dbs.email.port}")
	String port;
	
	public EmailService() {
		System.out.println("Inside EmailService constructor!!!!!");
	}

	public void send() {
		System.out.printf("APP NAME - %s, Mail is sent to  : %s using SMTP host as %s and PORT as %s%n", title,"Bill Gates",host,port);
		System.out.printf("MAIL STAMP IS - %s%n", uniqueStamp);
	}
}
