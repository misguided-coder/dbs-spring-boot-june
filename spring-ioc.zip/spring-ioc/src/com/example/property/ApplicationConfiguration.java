package com.example.property;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
@ComponentScan("com.example.property")
public class ApplicationConfiguration {
	
	@Bean
	public static PropertyPlaceholderConfigurer loadPopertiesData() {
		
		Resource dataResource = new ClassPathResource("com/example/property/data.properties");
		Resource dbResource = new ClassPathResource("com/example/property/db.properties");
		Resource[] resourses = {dataResource,dbResource};
		
		PropertyPlaceholderConfigurer propertyLoader = new PropertyPlaceholderConfigurer();
		//propertyLoader.setLocation(resource);
		propertyLoader.setLocations(resourses);
		return propertyLoader;
	}
	
}
