package com.example.annotation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"com/example/annotation/appCxt.xml");
		System.out.println("IoC Container is started");

		Calculator calculator = applicationContext.getBean("calculator",Calculator.class); 
		calculator.sum(10, 2);
		calculator.diff(10, 2);

		EmailService emailService = applicationContext.getBean("emailService",EmailService.class);
		emailService.send();
		

		AccountService accountService = applicationContext.getBean("accountService",AccountService.class);
		accountService.deposit();
			
		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
