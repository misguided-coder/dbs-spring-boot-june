package com.example.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AccountService {

	@Value("5001")
	int accountNo;
	
	@Autowired
	//@Qualifier("oracleDAO")
	AccountDAO mysqlDAO;

	public void deposit() {
		System.out.println("Inside AccountService deposit()!!!!");
		System.out.printf("Amount deposited to : %s%n", accountNo);
		mysqlDAO.update();
	}
}
