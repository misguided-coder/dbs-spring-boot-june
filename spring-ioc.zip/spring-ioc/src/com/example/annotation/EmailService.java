package com.example.annotation;

import org.springframework.stereotype.Component;

@Component
public class EmailService {

	public EmailService() {
		System.out.println("Inside EmailService constructor!!!!!");
	}

	public void send() {
		System.out.printf("Mail is sent to  : %s%n", "Bill Gates");
	}
}
