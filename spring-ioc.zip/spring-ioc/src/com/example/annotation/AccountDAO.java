package com.example.annotation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AccountDAO {

	@Value("H2")
	String database;

	public void setDatabase(String database) {
		this.database = database;
	}

	public void update() {
		System.out.println("Inside AccountDAO update()!!!!");
		System.out.printf("Data updated in %s DB!!%n", database);
	}
}
