package com.example.lifecycle;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		// IoC Container is started
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/example/lifecycle/appCxt.xml");
		System.out.println("IoC Container is started");

		Calculator calculator = (Calculator) applicationContext.getBean("calculator"); //IoC Style
		// calculator.sum(10, 2);
		// calculator.diff(10, 2);

		// IoC Container is stopped
		applicationContext.close();
		System.out.println("IoC Container is stopped");
	}
}
