package com.example.lifecycle;

public class Calculator {

	public Calculator() {
		System.out.println("Inside Calculator constructor!!!!!");
	}

	public void init() {
		System.out.println("Inside Calculator init()!!!!!");
		//10 LOC
	}

	public void clean() {
		System.out.println("Inside Calculator clean()!!!!!");
		//5 LOC
	}
		
	public void sum(int arg1, int arg2) {
		System.out.printf("SUM : %s%n", arg1 + arg2);
	}

	public void diff(int arg1, int arg2) {
		System.out.printf("DIFF : %s%n", arg1 - arg2);
	}

}
