package com.example.service;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.WeatherDAO;

@Service
public class WeatherService {
	
	@Autowired
	WeatherDAO weatherDAO;	

	Logger logger = Logger.getLogger(WeatherService.class.getName());

	public String readByCity(String cityName) {
		logger.info("Inside readByCity!!");
		return weatherDAO.selectByCity(cityName);
	}
}
