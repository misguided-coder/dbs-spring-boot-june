package com.example.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Repository;

@Repository
public class WeatherDAO {

	Logger logger = Logger.getLogger(WeatherDAO.class.getName());
	Map<String, String> weatherDB = null;
	
	@PostConstruct
	public void init() {
		weatherDB = new HashMap<>();
		weatherDB.put("Delhi", "Very Very Hot");
		weatherDB.put("Pune", "Very Cool");
		weatherDB.put("Hyderabad", "Cool");
	}
	
	@PreDestroy
	public void clean() {
		weatherDB.clear();
		weatherDB = null;
	}
	
	public String selectByCity(String cityName) {
		logger.info("Inside selectByCity!!");
		return weatherDB.get(cityName);
	}
}
