package com.example.controller;

import java.util.logging.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(path="/news")
public class NewsController {

	Logger logger = Logger.getLogger(NewsController.class.getName());
	
	@RequestMapping(path="/")
	public String newsPage() {
		logger.info("Inside newsPage()!!!!");
		return "news";
	}

	@RequestMapping(path="/politics")
	public ModelAndView politicsNewsPage() {
		logger.info("Inside politicsNewsPage()!!!!");
		ModelAndView modelAndView = new ModelAndView("news","NEWS-DATA","Politics is a good business.");
		return modelAndView;
	}
	
	@RequestMapping(path="/sports")
	public ModelAndView sportsNewsPage() {
		logger.info("Inside sportsNewsPage()!!!!");
		ModelAndView modelAndView = new ModelAndView("news","NEWS-DATA","Cricket is a good sports.");
		return modelAndView;
	}

}
