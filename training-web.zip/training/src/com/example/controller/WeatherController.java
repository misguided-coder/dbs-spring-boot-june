package com.example.controller;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.service.WeatherService;

@Controller
public class WeatherController {
	
	@Autowired
	WeatherService weatherService;	

	Logger logger = Logger.getLogger(WeatherController.class.getName());
	
	@RequestMapping(path="/weather/info")
	public ModelAndView weatherByCityPage(@RequestParam("city") String cityName) {
		logger.info("Inside weatherByCityPage()!!!!");
		String weatherInfo = weatherService.readByCity(cityName);
		ModelAndView modelAndView = new ModelAndView("weather","WEATHER-INFO","Weather is "+weatherInfo+" in "+cityName);
		return modelAndView;
	}
	
	@RequestMapping(path="/weather")
	public ModelAndView weatherPage() {
		logger.info("Inside weatherPage()!!!!");
		ModelAndView modelAndView = new ModelAndView("weather","WEATHER-INFO","Weather is cool outside.");
		return modelAndView;
	}
	
}
