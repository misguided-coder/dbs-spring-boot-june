insert into fuel_pump_master values(1,'HP Petroleum','Karol Bagh','Delhi');
insert into fuel_pump_master values(2,'Indian Oil','Dwarka','Delhi');
insert into fuel_pump_master values(3,'Indian Oil','Baner','Pune');
insert into fuel_pump_master values(4,'HP Petroleum','Gachibowli','Hyderabad');
insert into fuel_pump_master values(5,'HP Petroleum','Madhapur','Hyderabad');
insert into fuel_pump_master values(6,'Indian Oil','Baner','Chennai');
