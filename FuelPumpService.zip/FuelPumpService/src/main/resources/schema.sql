DROP TABLE IF EXISTS fuel_pump_master;

CREATE TABLE fuel_pump_master(
	id INT NOT NULL,
	title VARCHAR(30) NOT NULL,
	address VARCHAR(30) NOT NULL,
	city VARCHAR(30) NOT NULL,
	PRIMARY KEY (id));