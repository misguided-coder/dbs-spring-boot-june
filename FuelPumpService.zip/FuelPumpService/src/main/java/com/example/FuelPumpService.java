package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FuelPumpService {

	@Autowired
	FuelPumpDAO fuelPumpDAO;

	public FuelReceipt readfindPumpDetailByAddress(String address) {
		System.out.println("Inside FuelPumpService.readfindPumpDetailByAddress()!!!!!");
		return fuelPumpDAO.findPumpDetailByAddress(address);
	}

}
