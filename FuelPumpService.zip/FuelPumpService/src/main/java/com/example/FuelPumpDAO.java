package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FuelPumpDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public FuelReceipt findPumpDetailByAddress(String address) {
		System.out.println("Inside FuelPumpDAO.findPumpDetailByAddress()!!!!!");
		Object parms[] = { address };
		return jdbcTemplate.queryForObject("select * from fuel_pump_master where address=?", parms, new FuelReceiptRowMapper());
	}
}
