package com.example;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class FuelReceiptRowMapper implements RowMapper<FuelReceipt> {

	@Override
	public FuelReceipt mapRow(ResultSet rs, int rowNum) throws SQLException {
		FuelReceipt fuelReceipt = new FuelReceipt();
		fuelReceipt.setId(rs.getInt(1));
		fuelReceipt.setTitle(rs.getString(2));
		fuelReceipt.setAddress(rs.getString(3));
		fuelReceipt.setCity(rs.getString(4));
		return fuelReceipt;
	}

}
