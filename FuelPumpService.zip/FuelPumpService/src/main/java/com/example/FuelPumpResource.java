package com.example;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

//Spring MVC imports
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping(path = "/API")
public class FuelPumpResource {

	Logger logger = Logger.getLogger(FuelPumpResource.class.getName());
	
	@Autowired
	FuelPriceProxyService fuelPriceProxyService;
	
	@Autowired
	FuelPriceLoadBalancerProxyService fuelPriceLoadBalancerProxyService;
	
	@Autowired
	FuelPumpService fuelPumpService;

	@GetMapping(path = "/INFO/ADDRESS/{address}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public FuelReceipt getPumpDetails(@PathVariable("address") String address) {
		logger.info("================ Inside getPumpDetails() ===================");
		return fuelPumpService.readfindPumpDetailByAddress(address);
	}

	@GetMapping(path = "/FILL/LITERS/{liters}/ADDRESS/{address}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public FuelReceipt fillVehicle(@PathVariable("liters") int liters, @PathVariable("address") String address) {
		logger.info("================ Inside fillVehicle() ===================");
		FuelReceipt fuelReceipt = fuelPumpService.readfindPumpDetailByAddress(address);
		
		Map<String, String> uriVariables = new HashMap<>(); 
		uriVariables.put("cityName",fuelReceipt.getCity());
		
		//Make a call to FuelPriceMicroService for getting todays price
		RestTemplate restTemplate = new RestTemplate();
		String fuelPriceServiceURI = "http://localhost:8001/FUELPRICE/API/CITY/{cityName}";
		
		ResponseEntity<FuelReceipt> responseEntity = restTemplate.getForEntity(fuelPriceServiceURI, FuelReceipt.class, uriVariables);
		FuelReceipt responseReceipt = responseEntity.getBody();
		
		FuelReceipt receipt = new FuelReceipt(fuelReceipt.getId(), fuelReceipt.getTitle(), address, fuelReceipt.getCity(), responseReceipt.getTodayPrice(), liters, liters*responseReceipt.getTodayPrice());
		
		return receipt;
	}

	@GetMapping(path = "/FILL/FAST/LITERS/{liters}/ADDRESS/{address}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public FuelReceipt fillVehicleFast(@PathVariable("liters") int liters, @PathVariable("address") String address) {
		logger.info("================ Inside fillVehicleFast() ===================");
		FuelReceipt fuelReceipt = fuelPumpService.readfindPumpDetailByAddress(address);
		
		//Make a call to FuelPriceMicroService for getting todays price using Feign REST Client Library
		FuelReceipt responseReceipt = fuelPriceProxyService.getTodayPrice(fuelReceipt.getCity());

		FuelReceipt receipt = new FuelReceipt(fuelReceipt.getId(), fuelReceipt.getTitle(), address, fuelReceipt.getCity(), responseReceipt.getTodayPrice(), liters, liters*responseReceipt.getTodayPrice());
		
		return receipt;
	}
	
	
	@GetMapping(path = "/FILL/FAST/BALANCER/LITERS/{liters}/ADDRESS/{address}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public FuelReceipt fillVehicleFastLoadBalancer(@PathVariable("liters") int liters, @PathVariable("address") String address) {
		logger.info("================ Inside fillVehicleFastLoadBalancer() ===================");
		FuelReceipt fuelReceipt = fuelPumpService.readfindPumpDetailByAddress(address);
		
		/*Make a call to FuelPriceMicroService for getting todays price 
		 * using Feign REST Client Library and Ribbon as Load Balancer
		 */
		FuelReceipt responseReceipt = fuelPriceLoadBalancerProxyService.getTodayPrice(fuelReceipt.getCity());

		FuelReceipt receipt = new FuelReceipt(fuelReceipt.getId(), fuelReceipt.getTitle(), address, fuelReceipt.getCity(), responseReceipt.getTodayPrice(), liters, liters*responseReceipt.getTodayPrice());
		
		return receipt;
	}

}
