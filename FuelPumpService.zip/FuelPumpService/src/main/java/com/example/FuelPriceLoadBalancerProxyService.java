package com.example;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name = "FuelPriceService")
@RibbonClient(name = "FuelPriceService")
public interface FuelPriceLoadBalancerProxyService {
	@RequestMapping(path = "/FUELPRICE/API/CITY/{cityName}")
	public FuelReceipt getTodayPrice(@PathVariable("cityName") String city);
}
