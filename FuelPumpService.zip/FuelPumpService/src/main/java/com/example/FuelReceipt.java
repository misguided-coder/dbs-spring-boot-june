package com.example;

public class FuelReceipt {

	int id;
	String title;
	String address;
	String city;
	double todayPrice;
	int litres;
	double totalAmount;

	public FuelReceipt() {
	}

	public FuelReceipt(String title, String address, String city, double todayPrice, int litres, double totalAmount) {
		this.title = title;
		this.address = address;
		this.city = city;
		this.todayPrice = todayPrice;
		this.litres = litres;
		this.totalAmount = totalAmount;
	}

	public FuelReceipt(int id, String title, String address, String city, double todayPrice, int litres,
			double totalAmount) {
		this.id = id;
		this.title = title;
		this.address = address;
		this.city = city;
		this.todayPrice = todayPrice;
		this.litres = litres;
		this.totalAmount = totalAmount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public double getTodayPrice() {
		return todayPrice;
	}

	public void setTodayPrice(double todayPrice) {
		this.todayPrice = todayPrice;
	}

	public int getLitres() {
		return litres;
	}

	public void setLitres(int litres) {
		this.litres = litres;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

}
